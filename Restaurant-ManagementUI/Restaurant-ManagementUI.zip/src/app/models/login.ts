export class Login{
    
    email: string
    password: string
    
    constructor() {
      
       this.email = ''
       this.password = ''
       
    }
 }
 