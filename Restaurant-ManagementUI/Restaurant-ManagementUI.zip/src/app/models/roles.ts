export enum Roles {
    // nseit_ho = 'nseit_ho',
    // nseit_state = 'nseit_state',
    // client = 'client'
    admin = 'admin',
    
  }