export class Register{
   name: string
   email: string
   password: string
   cpassword:string
   constructor() {
      this.name = ''
      this.email = ''
      this.password = ''
      this.cpassword = ''
   }
}
