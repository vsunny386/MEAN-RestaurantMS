export class Checkout{
    id:string
    cartItems: [];
    address: string;
    name: string;
    email: string;
    amount: number;
    contact: number;
    mode_of_payment: string
}